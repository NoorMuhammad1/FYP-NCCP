export const microorganismTemplate = {
  CoreDataSets: {
    Genus: String,
    AccessionNumber: String,
    OtherCollection: Array,
  },
  Name: {},
};

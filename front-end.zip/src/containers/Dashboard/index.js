import React from "react";
import SideBar from "../../components/SideBar";
// import AdminDashboardDetails from "../../components/AdminDashboardDetails";
const Dashboard = () => {
  return <SideBar>{/* <AdminDashboardDetails /> */}</SideBar>;
};

export default Dashboard;

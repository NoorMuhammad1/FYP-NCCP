import React from "react";
import Layout from "../../components/Layout";

const Orders = (props) => {
  console.log("Order Component");
  return (
    <Layout sidebar>
      <h1>Order Component</h1>
    </Layout>
  );
};

export default Orders;

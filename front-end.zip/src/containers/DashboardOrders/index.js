import React from "react";
import SideBar from "../../components/SideBar";

const DashboardOrders = () => {
  return (
    <SideBar active="Orders">
      <h1>Dashboard Orders</h1>
    </SideBar>
  );
};

export default DashboardOrders;

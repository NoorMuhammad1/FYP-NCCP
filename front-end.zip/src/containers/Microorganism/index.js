import React from "react";
import Layout from "../../components/Layout";

const Microorganism = (props) => {
  return <Layout sidebar>Microorganism</Layout>;
};

export default Microorganism;

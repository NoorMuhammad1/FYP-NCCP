import React from "react";
import SideBar from "../../components/SideBar";

const DashboardDeposits = () => {
  return (
    <SideBar>
      <div style={{ backgroundColor: "red" }}>DashboardDeposits</div>
    </SideBar>
  );
};

export default DashboardDeposits;

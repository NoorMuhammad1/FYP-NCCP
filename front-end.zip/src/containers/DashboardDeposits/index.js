import React from "react";
import SideBar from "../../components/SideBar";

const DashboardDeposits = () => {
  return (
    <SideBar active="Deposits">
      <h1>Dashboard Deposits</h1>
    </SideBar>
  );
};

export default DashboardDeposits;

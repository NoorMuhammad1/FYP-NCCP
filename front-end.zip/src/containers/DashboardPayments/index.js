import React from "react";
import SideBar from "../../components/SideBar";

const DashboardPayments = () => {
  return (
    <SideBar active="Payments">
      <div style={{ backgroundColor: "red" }}>DashboardPayments34583940</div>
    </SideBar>
  );
};

export default DashboardPayments;

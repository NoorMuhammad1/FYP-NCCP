import React from "react";
import SideBar from "../../components/SideBar";

const AdminDashboardDetails = () => {
  return (
    <SideBar active="Dashboard">
      <h1>Main Dashboard</h1>
    </SideBar>
  );
};

export default AdminDashboardDetails;

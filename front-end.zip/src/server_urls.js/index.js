const urls = {
  FETCH_CATALOGUE_DATA_URL: "http://localhost:2000/api/getSearchInfo",
  FETCH_ITEM_DATA_URL: "http://localhost:2000/api/findMicroorganism",
  FETCH_DASHBOARD_DATA_URL: "http://localhost:2000/api/dashboardData",
  FETCH_USER_DATA_URL: "http://localhost:2000/api/users",
  UPDATE_USER_DATA_URL: "http://localhost:2000/api/updateUser",
};

export default urls;

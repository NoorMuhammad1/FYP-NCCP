import React from "react";
import "./style.css";
const ItemListCard = () => {
  return <div>ItemListCard</div>;
};

export default ItemListCard;

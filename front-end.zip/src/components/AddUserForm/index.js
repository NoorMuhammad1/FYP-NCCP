import React from "react";
import Layout from "../Layout";

const AddUserForm = () => {
  return <Layout sidebar>add user</Layout>;
};

export default AddUserForm;

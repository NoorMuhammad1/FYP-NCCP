import React from "react";

import "../Logo/index.css";

const Logo = (props) => {
  return (
    <div>
      <p>NCCP</p>
      <p>Information System</p>
    </div>
  );
};

export default Logo;

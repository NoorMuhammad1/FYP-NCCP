import React from "react";
import SideBar from "../SideBar";

const Deposits = () => {
  return (
    <SideBar>
      <div style={{ backgroundColor: "red" }}>Deposits</div>
    </SideBar>
  );
};

export default Deposits;

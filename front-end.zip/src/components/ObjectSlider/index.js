import React from "react";
import Carousel from "react-elastic-carousel";
import Bacteria_Archaea from "./Icons/Bacteria_Archaea.png";
import Fungi from "./Icons/Fungi.png";
import Plant_Viruses from "./Icons/Plant-Viruses.png";
import Phage from "./Icons/Bacteriophage.png";
import Item from "./Item.js";

const ObjectSlider = () => {
  const breakPoints = [
    { width: 1, itemsToShow: 1 },
    { width: 550, itemsToShow: 2, itemsToScroll: 2 },
    { width: 768, itemsToShow: 3 },
    { width: 1200, itemsToShow: 4 },
  ];
  const items = [
    { image: Bacteria_Archaea, title: "Bacteria", strains: 3466 },
    { image: Plant_Viruses, title: "Algae", strains: 3466 },
    { image: Fungi, title: "Fungi", strains: 3466 },
    { image: Fungi, title: "Yeast", strains: 3466 },
    { image: Bacteria_Archaea, title: "MicroAlgae", strains: 3466 },
    { image: Phage, title: "Phage", strains: 3466 },
    { image: Bacteria_Archaea, title: "Archaea", strains: 3466 },
    { image: Plant_Viruses, title: "Virus", strains: 3466 },
    { image: Phage, title: "Antibody", strains: 3466 },
  ];
  return (
    <div>
      <Carousel breakPoints={breakPoints} style={{ width: "85vw" }}>
        {items.map((item, index) => {
          return (
            <Item key={index}>
              <img src={item.image} />
              <h3>{item.title}</h3>
              <p>{`${item.strains} strains`}</p>
            </Item>
          );
        })}
      </Carousel>
    </div>
  );
};

export default ObjectSlider;

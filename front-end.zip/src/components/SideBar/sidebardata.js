import HomeIcon from "@material-ui/icons/Home";
import PeopleIcon from "@material-ui/icons/People";
// import { ReactComponent as Cell } from "./Icons/cell.svg";
import PeopleRoundedIcon from "@material-ui/icons/PeopleRounded";
import ListAltIcon from "@material-ui/icons/ListAlt";
import AccountBalanceIcon from "@material-ui/icons/AccountBalance";
import AssessmentIcon from "@material-ui/icons/Assessment";
import ExitToAppIcon from "@material-ui/icons/ExitToApp";
import DashboardIcon from "@material-ui/icons/Dashboard";
export const sidebarData = [
  {
    title: "Dashboard",
    icon: <DashboardIcon />,
    link: "/AdminDashboard",
  },
  {
    title: "Users",
    icon: <PeopleRoundedIcon />,
    link: "/dashboard/users",
  },
  {
    title: "Orders",
    icon: <ListAltIcon />,
    link: "/dashboard/orders",
  },
  {
    title: "Reports",
    icon: <AssessmentIcon />,
    link: "/dashboard/reports",
  },
  // {
  //   title: "Logout",
  //   icon: <ExitToAppIcon />,
  //   link: "/dashboard/logout",
  // },
];
